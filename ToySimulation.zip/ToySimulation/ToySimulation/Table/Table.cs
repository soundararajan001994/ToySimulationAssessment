﻿namespace ToySimulation
{
    public class Table
    {
        public int tableSize { get; set; } = 5;
    }
}
